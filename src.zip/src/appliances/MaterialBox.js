import Appliance from './Appliance'
import LevelUtil from '../util/LevelUtil'
import Items from '../util/Items'

/**
 * Abstract material box to output materials - we should NOT be using this in production build
 */
export default class MaterialBox extends Appliance {

    constructor(x,y,scene,initialSprite,materialType){
        super(x,y,scene);
        if (!(materialType in Items.itemList)) throw "MaterialBox class: Constructor: invalid materialType specified";
        this.setMaterialType(materialType);
    }

    setMaterialType(materialType){
        this.materialType = materialType;
        this.updatePhaserLogic(null);
    }

    interact(item){
        if (item === null) {
            this.updatePhaserLogic(true);
            return this.materialType;
        }
        if (item === this.materialType) {
            this.updatePhaserLogic(false);
            return null;
        }
        else return item;
    }

    //TODO
    initializePhaserLogic(scene,initialSprite){
        return scene.add.rectangle(this.x,this.y,LevelUtil.tileSize,LevelUtil.tileSize,0xffffff);
    }

    //Do nothing?
    updatePhaserLogic(...args){
        if (args[0] === null) {
            this.visual.fillColor = Items.itemList[this.materialType]["color"];
            return;
        }
        if (args[0]) alert("Withdrawing");
        else alert("Depositing");
    }


}