import Phaser from 'phaser'

import TitleScreen from './scenes/TitleScene'
import Game from './scenes/Game'


import LevelUtil from './util/LevelUtil'

const config = {
    type: Phaser.AUTO,
    scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
        width: LevelUtil.gamePixSize[0],
        height: LevelUtil.gamePixSize[1]
    }
}

const game = new Phaser.Game(config);

// Add screens to the scene
game.scene.add('game', Game)
game.scene.add('titlescreen', TitleScreen)


game.scene.start('game')