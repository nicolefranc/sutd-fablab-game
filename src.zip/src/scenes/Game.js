import Phaser from 'phaser'
import Items from '../util/Items'
import LevelUtil from '../util/LevelUtil'
import ItemController from '../controllers/ItemController';
import ScoreController from '../controllers/ScoreController'
import AssemblyTable from '../appliances/AssemblyTable';


const level = require('../dungeon-01.json');

export default class Game extends Phaser.Scene {
    preload() {
        //alert('/scenes/tiles/dungeon-01.json');
        this.load.json('jsonData', level);
        //this.load.tilemapTiledJSON('dungeon',process.env.PUBLIC_URL+'/scenes/tiles/dungeon-01.json');
    }

    create() {
        this.scenario2();

    }

    scenario1() {
        this.item = null;
        this.add.text(400, 250, 'Game')
        this.table = new WaitingTool(100,100,this,null,"wood","metalSheet",10,2000,10,2000,0.1);
        this.rSelected = this.add.rectangle(100,300,LevelUtil.tileSize,LevelUtil.tileSize,0x000000);
        this.rWood = this.add.rectangle(100,400,LevelUtil.tileSize,LevelUtil.tileSize,0xff0000);
        this.rWood.setInteractive();
        this.rWood.on('pointerup', () => {
            this.item = "wood";
            this.rSelected.fillColor = Items.itemList["wood"]["color"];
            alert("Loaded wood onto player");
        });
        this.rFilament = this.add.rectangle(200,400,LevelUtil.tileSize,LevelUtil.tileSize,0x00ff00);
        this.rFilament.setInteractive();
        this.rFilament.on('pointerup', () => {
            this.item = "filament";
            this.rSelected.fillColor = Items.itemList["filament"]["color"];
            alert("Loaded filament onto player");
        });
        this.rMetalSheet = this.add.rectangle(300,400,LevelUtil.tileSize,LevelUtil.tileSize,0x0000ff);
        this.rMetalSheet.setInteractive();
        this.rMetalSheet.on('pointerup', () => {
            this.item = "metalSheet";
            this.rSelected.fillColor = Items.itemList["metalSheet"]["color"];
            alert("Loaded metal sheet onto player");
        });
        this.rMetalSheet = this.add.rectangle(400,400,LevelUtil.tileSize,LevelUtil.tileSize,0x000000);
        this.rMetalSheet.setInteractive();
        this.rMetalSheet.on('pointerup', () => {
            this.item = null;
            this.rSelected.fillColor = "0x000000";
            alert("Loaded null onto player");
        });

        this.rSelected.setInteractive();
        this.rSelected.on('pointerup', () => {
            this.item = this.table.interact(this.item);
            if (this.item !== null) this.rSelected.fillColor = Items.itemList[this.item]["color"];
            else this.rSelected.fillColor = "0x000000";
        });
    }

    scenario2(){
        this.itemController = new ItemController(400,250,this,null,["wood","filament","metalSheet"],3);
        this.scoreController = new ScoreController(400,150,this);
        this.assemblyTable = new AssemblyTable(100,300,this,null);
        this.assemblyTable.attachItemController(this.itemController);
        this.assemblyTable.attachScoreController(this.scoreController);
        this.rWood = this.add.rectangle(100,400,LevelUtil.tileSize,LevelUtil.tileSize,0xff0000);
        this.rWood.setInteractive();
        this.rWood.on('pointerup', () => {
            this.assemblyTable.interact("wood");
        });
        this.rFilament = this.add.rectangle(200,400,LevelUtil.tileSize,LevelUtil.tileSize,0x00ff00);
        this.rFilament.setInteractive();
        this.rFilament.on('pointerup', () => {
            this.assemblyTable.interact("filament");
        });
        this.rMetalSheet = this.add.rectangle(300,400,LevelUtil.tileSize,LevelUtil.tileSize,0x0000ff);
        this.rMetalSheet.setInteractive();
        this.rMetalSheet.on('pointerup', () => {
            this.assemblyTable.interact("metalSheet");
        });
        this.rMetalSheet = this.add.rectangle(400,400,LevelUtil.tileSize,LevelUtil.tileSize,0x000000);
        this.rMetalSheet.setInteractive();
        this.rMetalSheet.on('pointerup', () => {
            this.assemblyTable.interact(null);
        });
    }
}