export default class Items {
    static get itemList() {
        return {
            "acrylic": {
                "color": "0x000000"
            },
            "pcb": {
                "color": "0x000000"
            },
            "wood": {
                "color": "0xff0000"
            },
            "filament": {
                "color": "0x00ff00"
            },
            "metalSheet": {
                "color": "0x0000ff"
            },
            "jigsawAcrylic": {
                "color": "0x000000"
            },
            "jigsawWood": {
                "color": "0x000000"
            },
            "jigsawMetal": {
                "color": "0x000000"
            },
            "acrylicStrips": {
                "color": "0x000000"
            },
            "woodStrips": {
                "color": "0x000000"
            },
            "metalStrips": {
                "color": "0x000000"
            },
            "donutAcrylic": {
                "color": "0x000000"
            },
            "donutWood": {
                "color": "0x000000"
            },
            "donutMetal": {
                "color": "0x000000"
            }
            
        };
        
    }
}